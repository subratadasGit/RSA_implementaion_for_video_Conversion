const express = require('express');
const forge = require('node-forge');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json({ limit: '50mb' }));

// Generate RSA key pair
const keypair = forge.pki.rsa.generateKeyPair(2048);
const publicKeyPem = forge.pki.publicKeyToPem(keypair.publicKey);
const privateKeyPem = forge.pki.privateKeyToPem(keypair.privateKey);

app.get('/public-key', (req, res) => {
    res.send({ publicKey: publicKeyPem });
});

app.post('/encrypt', (req, res) => {
    const { videoDataBase64 } = req.body;

    // Decode the video data
    const videoDataBytes = forge.util.decode64(videoDataBase64);

    // generation random key
    const aesKey = forge.random.getBytesSync(16);

    
    const cipher = forge.cipher.createCipher('AES-CBC', aesKey);
    cipher.start({ iv: forge.random.getBytesSync(16) });
    cipher.update(forge.util.createBuffer(videoDataBytes));
    cipher.finish();
    const encryptedVideoData = cipher.output.getBytes();

    // AES key with RSA key
    const encryptedAesKey = keypair.publicKey.encrypt(aesKey);

    res.send({
        encryptedAesKey: forge.util.encode64(encryptedAesKey),
        encryptedVideoData: forge.util.encode64(encryptedVideoData),
    });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
